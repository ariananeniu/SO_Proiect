#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <dirent.h>
#include <sys/wait.h> 

typedef struct {
    int id;
    char inspector[50];
    float lat, lon;
    char category[32];
    int severity;
    time_t timestamp;
    char description[256];
}Report;

//Golește buffer-ul stdin (aruncă resturile precum '\n' lăsat de scanf) 
//pentru a nu bloca următoarele citiri de tip fgets.
void clear_input_line(void) {
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF);
}

// Convertește sigur un string ('text') în int ('value') folosind strtol.
int parse_int_arg(const char *text, int *value) {
    char *end = NULL;
    long parsed = strtol(text, &end, 10);

    if (text == end || *end != '\0') {
        return 0;
    }

    *value = (int)parsed;
    return 1;
}

//Parcurge fisierul binar pentru a gasi cel mai mare ID de raport existent.
//Returneaza max_id + 1 pentru noul raport (sau 1 daca fisierul e gol/nu exista). 
int next_report_id(const char *path) {
    int fd = open(path, O_RDONLY);
    int max_id = 0;
    Report r;

    if (fd == -1) {
        return 1;
    }

    while (read(fd, &r, sizeof(Report)) == sizeof(Report)) {
        if (r.id > max_id) {
            max_id = r.id;
        }
    }

    close(fd);
    return max_id + 1;
}

//Transforma bitii de permisiuni din st_mode intr-un format text prin operatii pe biti. 
void get_permissions(mode_t mode, char *str) {
    strcpy(str, "---------");
    if (mode & S_IRUSR) str[0] = 'r';
    if (mode & S_IWUSR) str[1] = 'w';
    if (mode & S_IXUSR) str[2] = 'x';
    if (mode & S_IRGRP) str[3] = 'r';
    if (mode & S_IWGRP) str[4] = 'w';
    if (mode & S_IXGRP) str[5] = 'x';
    if (mode & S_IROTH) str[6] = 'r';
    if (mode & S_IWOTH) str[7] = 'w';
    if (mode & S_IXOTH) str[8] = 'x';
}

//Verifica permisiunile fisierului folosind apelul stat().
//Daca fisierul exista dar nu contine bitul necesar (required_bit),
//scrie eroarea la STDERR si opreste fortat executia programului.
void check_access(const char *path, mode_t required_bit, const char *msg) {
    struct stat st;
    if (stat(path, &st) == -1) return; // Fișierul nu există încă, trecem mai departe
    if (!(st.st_mode & required_bit)) {
        fprintf(stderr, "[EROARE ACCES]: %s\n", msg);
        exit(EXIT_FAILURE);
    }
}


/*Funcția log_action generează și gestionează jurnalul de activități (logged_district).
Actioneaza ca un filtru de securitate: foloseste stat() pentru a bloca inspectorii
sa scrie in log sau sa il creeze, impunand restrictiile rolului (permisiuni 644).
Apoi deschide fisierul in mod APPEND si il scrie pe disc prin intermediul apelului de sistem write().
 */
void log_action(const char *district, const char *role, const char *user, const char *action) {
    if (strcmp(role, "inspector") == 0) {
        printf("[AVERTISMENT] Inspectorii nu au drept de scriere in log.\n");
        return;
    }

    char path_log[1024];
    snprintf(path_log, sizeof(path_log), "%s/logged_district", district);

    struct stat st;
    if (stat(path_log, &st) == 0) {
        if (strcmp(role, "inspector") == 0 && !(st.st_mode & S_IWGRP)) {
            printf("[AVERTISMENT] Inspectorii nu au drept de scriere in log.\n");
            return;
        }
    } else {
        if (strcmp(role, "inspector") == 0) {
            printf("[AVERTISMENT] Inspectorii nu au permisiunea de a crea/scrie in log.\n");
            return;
        }
    }


    int log_fd = open(path_log, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (log_fd != -1) {
        chmod(path_log, 0644);
        char log_entry[512];
        snprintf(log_entry, sizeof(log_entry), "[%ld] Role: %s, User: %s, Action: %s\n", time(NULL), role, user, action);
        write(log_fd, log_entry, strlen(log_entry));
        close(log_fd);
    }
}

/*Notifică procesul de fundal (monitor_reports) cu privire la o nouă acțiune.
Funcția citește PID-ul procesului țintă din fișierul de configurare ".monitor_pid"
și folosește apelul de sistem kill() pentru a-i transmite semnalul asincron SIGUSR1.
Indiferent de rezultat, rezultatul operațiunii IPC este înregistrat obligatoriu în jurnalul districtului.*/
void notify_monitor(const char *district, const char *role, const char *user) {
    FILE *f = fopen(".monitor_pid", "r");
    char action_msg[256];

    if (!f) {
        snprintf(action_msg, sizeof(action_msg), "NOTIFICARE MONITOR: ESUAT (Monitorul nu ruleaza)");
        log_action(district, role, user, action_msg);
        return;
    }

    pid_t monitor_pid;
    if (fscanf(f, "%d", &monitor_pid) != 1) {
        snprintf(action_msg, sizeof(action_msg), "NOTIFICARE MONITOR: ESUAT (Fisier PID invalid)");
    } else {
        if (kill(monitor_pid, SIGUSR1) == 0) {
            snprintf(action_msg, sizeof(action_msg), "NOTIFICARE MONITOR: SUCCES (Trimis catre PID %d)", monitor_pid);
        } else {
            snprintf(action_msg, sizeof(action_msg), "NOTIFICARE MONITOR: ESUAT (Eroare semnal)");
        }
    }

    fclose(f);
    log_action(district, role, user, action_msg);
}

/* Gestioneaza shortcut-ul (link simbolic) catre fisierul binar al districtului.
Daca un link vechi exista, lstat verifica identitatea lui, iar stat() verifica 
daca tinta inca exista. In final, sterge link-ul vechi (unlink) si creeaza unul pnou (symlink).*/
void handle_symlink(const char *district) {
    char link_name[512], target_path[1024];
    snprintf(link_name, sizeof(link_name), "active_reports-%s", district);
    snprintf(target_path, sizeof(target_path), "%s/reports.dat", district);

    struct stat st;
    if (lstat(link_name, &st) == 0) {
        if (S_ISLNK(st.st_mode)) {
            struct stat st_target;
            if (stat(link_name, &st_target) == -1) {
                printf("[AVERTISMENT] Legatura intrerupta detectata (destinatia nu exista): %s\n", link_name);
            }
            unlink(link_name);
        }
    }
    symlink(target_path, link_name);
}

//Funcții generate cu asistența AI pentru Filter
int parse_condition(const char *input, char *field, char *op, char *value) {
    return sscanf(input, "%31[^:]:%4[^:]:%63s", field, op, value) == 3;
}

int match_condition(Report *r, const char *field, const char *op, const char *value) {
    double r_val = 0, c_val = 0;
    char *r_str = NULL;

    if (strcmp(field, "severity") == 0) {
        r_val = r->severity; c_val = atof(value);
    } else if (strcmp(field, "timestamp") == 0) {
        r_val = (double)r->timestamp; c_val = atof(value);
    } else if (strcmp(field, "category") == 0) {
        r_str = r->category;
    } else if (strcmp(field, "inspector") == 0) {
        r_str = r->inspector;
    } else return 0;

    if (r_str) {
        if (strcmp(op, "==") == 0) return strcmp(r_str, value) == 0;
        if (strcmp(op, "!=") == 0) return strcmp(r_str, value) != 0;
        return 0;
    }

    if (strcmp(op, "==") == 0) return r_val == c_val;
    if (strcmp(op, "!=") == 0) return r_val != c_val;
    if (strcmp(op, "<") == 0)  return r_val < c_val;
    if (strcmp(op, "<=") == 0) return r_val <= c_val;
    if (strcmp(op, ">") == 0)  return r_val > c_val;
    if (strcmp(op, ">=") == 0) return r_val >= c_val;
    return 0;
}


/*Afiseaza metadatele si continutul bazei de date (reports.dat) pentru un district.
Functionalitatea este impartita in doua etape:
   1.Foloseste apelul sistem stat() pentru a extrage si afisa metadatele de sistem 
   2. Citirea datelor: Deschide fisierul binar in mod read-only (O_RDONLY) si 
      il parcurge secvential cu apelul read(), extragand bucati de memorie de dimensiunea structurii Report.
 */
void list_reports(const char *district, const char *role) {
    char path[1024];
    snprintf(path, sizeof(path), "%s/reports.dat", district);

    // 1. OBTINEREA SI AFISAREA METADATELOR (Cerință obligatorie)
    struct stat st;
    if (stat(path, &st) == -1) {
        printf("Nu s-a gasit raportul in districtul '%s'.\n", district);
        return;
    }

    char perms[10];
    get_permissions(st.st_mode, perms);
    printf("--- METADATE FISIER ---\n");
    printf("Cale: %s\nPermisiuni: %s\nDimensiune: %lld bytes\nModificat: %s", path, perms, (long long)st.st_size, ctime(&st.st_mtime));
    printf("-----------------------\n");

    // 2. CITIREA SI AFISAREA CONTINUTULUI
    int fd = open(path, O_RDONLY);
    if (fd == -1) return;

    Report r;
    int count = 0;
    printf("Rapoarte:\n");

    while (read(fd, &r, sizeof(Report)) == sizeof(Report)) {
        count++;
        printf("Raport %d:\nID: %d\nInspector: %s\nCategorie: %s\nSeveritate: %d\nCoordonate: [%.4f, %.4f]\nDescriere: %s\nData: %s",
               count, r.id, r.inspector, r.category, r.severity, r.lat, r.lon, r.description, ctime(&r.timestamp));
        printf("----------------------------\n");
    }

    if (count == 0) {
        printf("Fisierul reports.dat exista, dar nu contine inregistrari\n");
    }

    close(fd);
}

void add(const char *district, const char *role, const char *user) {
    char path_dir[1024], path_file[1024], path_cfg[1024];

    Report r;
    memset(&r, 0, sizeof(Report));
    snprintf(path_dir, sizeof(path_dir), "%s", district);
    snprintf(path_file, sizeof(path_file), "%s/reports.dat", district);
    snprintf(path_cfg, sizeof(path_cfg), "%s/district.cfg", district);

    mkdir(path_dir, 0750);
    chmod(path_dir, 0750);


    if (strcmp(role, "manager") == 0) check_access(path_file, S_IWUSR, "Managerul nu are drept de scriere!");
    else check_access(path_file, S_IWGRP, "Inspectorul nu are drept de scriere!");


    int cfg_fd = open(path_cfg, O_CREAT | O_EXCL | O_WRONLY, 0640);
    if (cfg_fd != -1) close(cfg_fd);

    r.id = next_report_id(path_file);
    r.timestamp = time(NULL);
    strncpy(r.inspector, user, sizeof(r.inspector) - 1);

    printf("----- Introducere raport nou -----\n");
    printf("Categorie:\n");
    if (scanf("%31s", r.category) != 1) {
        printf("Categorie invalida.\n");
        clear_input_line();
        return;
    }
    clear_input_line();

    printf("Severitate (1-minor, 2-moderat, 3-critic): ");
    if (scanf("%d", &r.severity) != 1 || r.severity < 1 || r.severity > 3) {
        printf("Severitate invalida.\n");
        clear_input_line();
        return;
    }
    clear_input_line();

    printf("Coordonate (Latitudine longitudine): ");
    if (scanf("%f %f", &r.lat, &r.lon) != 2) {
        printf("Coordonate invalide.\n");
        clear_input_line();
        return;
    }
    clear_input_line();

    printf("Descriere scurta problema: ");
    if (fgets(r.description, sizeof(r.description), stdin) == NULL) {
        printf("Descriere invalida.\n");
        return;
    }
    r.description[strcspn(r.description, "\n")] = 0;

    int fd = open(path_file, O_WRONLY | O_CREAT | O_APPEND, 0664);
    if (fd == -1) { perror("Eroare la accesarea reports.dat"); return; }
    chmod(path_file, 0664);

    if (write(fd, &r, sizeof(Report)) == sizeof(Report)) {
        printf("Raport adaugat cu succes de catre %s (ID: %d)\n", user, r.id);

        char action[256];
        snprintf(action, sizeof(action), "ADD REPORT ID %d", r.id);
        log_action(district, role, user, action);

        // NOTIFICARE MONITOR
        notify_monitor(district, role, user);
    }
    close(fd);
}

void view(const char *district, int id_report) {
    char path_file[1024];
    snprintf(path_file, sizeof(path_file), "%s/reports.dat", district);

    int fd = open(path_file, O_RDONLY);
    if (fd == -1) {
        perror("Eroare la accesarea reports.dat");
        return;
    }

    Report r;
    int found = 0;
    while (read(fd, &r, sizeof(Report)) == sizeof(Report)) {
        if (r.id == id_report) {
            found = 1;
            printf("Inspector: %s\n", r.inspector);
            printf("Categorie: %s\n", r.category);
            printf("Severitate: %d\n", r.severity);
            printf("Coordonate:  Lat: %.4f | Lon: %.4f\n", r.lat, r.lon);
            printf("Data:        %s", ctime(&r.timestamp));
            printf("------------------------------------------\n");
            printf("DESCRIERE:\n%s\n", r.description);
            printf("==========================================\n\n");
            break;
        }
    }
    if (!found) {
        printf("[!] Eroare: Raportul cu ID-ul %d nu a fost gasit in districtul %s.\n", id_report, district);
    }

    close(fd);
}

void remove_district(const char *district, const char *role) {
    if (role == NULL || strcmp(role, "manager") != 0) {
        fprintf(stderr, "[EROARE] Acces refuzat: Doar managerul poate sterge un district.\n");
        return;
    }

    if (district == NULL || strlen(district) == 0 ||
        strcmp(district, ".") == 0 || strcmp(district, "..") == 0 || strchr(district, '/') != NULL) {
        fprintf(stderr, "[EROARE] Nume de district invalid.\n");
        return;
    }

    char link_name[512];
    snprintf(link_name, sizeof(link_name), "active_reports-%s", district);
    unlink(link_name); 

    
    pid_t pid = fork();
    
    if (pid < 0) {
        perror("[EROARE] fork a esuat");
    } else if (pid == 0) 
    {
        execlp("rm", "rm", "-rf", district, NULL);
        perror("[EROARE] exec a esuat");
        exit(EXIT_FAILURE);
    } else {
        int status;
        waitpid(pid, &status, 0);
        
        if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
            printf("[SUCCESS] Districtul '%s' si symlink-ul au fost eliminate folosind rm -rf.\n", district);
        } else {
            printf("[EROARE] Comanda rm a returnat o eroare.\n");
        }
    }
}

void remove_report(const char *district, const char *role, const char *user, int target_id) {

    if (strcmp(role, "manager") != 0) {
        fprintf(stderr, "[EROARE] Acces refuzat: Doar managerul poate sterge rapoarte.\n");
        return;
    }

    char path_file[1024];
    snprintf(path_file, sizeof(path_file), "%s/reports.dat", district);

    
    int fd = open(path_file, O_RDWR);
    if (fd == -1) {
        perror("Eroare la accesarea reports.dat");
        return;
    }

    Report r;
    off_t target_offset = -1;
    int found = 0;

    
    while (read(fd, &r, sizeof(Report)) == sizeof(Report)) {
        if (r.id == target_id) {
            found = 1;
            target_offset = lseek(fd, -sizeof(Report), SEEK_CUR);
            break;
        }
    }

    if (!found) {
        printf("[!] Raportul cu ID-ul %d nu a fost gasit in %s.\n", target_id, district);
        close(fd);
        return;
    }

    //Se muta cu o pozitie la stanga toate inregistrarile care urmeaza dup cel sters
    off_t read_offset = target_offset + sizeof(Report);
    off_t write_offset = target_offset;

    while (1) {
        lseek(fd, read_offset, SEEK_SET);
        int bytes_read = read(fd, &r, sizeof(Report));
        
        if (bytes_read <= 0) break; 

        lseek(fd, write_offset, SEEK_SET);
        write(fd, &r, sizeof(Report));

        read_offset += sizeof(Report);
        write_offset += sizeof(Report);
    }

    ftruncate(fd, write_offset);
    close(fd);

    printf("Raportul cu ID %d a fost sters cu succes.\n", target_id);

    char action[256];
    snprintf(action, sizeof(action), "REMOVE REPORT ID %d", target_id);
    log_action(district, role, user, action);
}


void filter_reports(const char *district, int argc, char *argv[], int start_idx) {
    char path[1024];
    snprintf(path, sizeof(path), "%s/reports.dat", district);
    int fd = open(path, O_RDONLY);
    if (fd == -1) { perror("Eroare la acces"); return; }

    Report r;
    while (read(fd, &r, sizeof(Report)) == sizeof(Report)) {
        int all_match = 1;
        for (int i = start_idx; i < argc; i++) {
            char field[32], op[5], value[64];
            if (parse_condition(argv[i], field, op, value)) {
                if (!match_condition(&r, field, op, value)) {
                    all_match = 0; break;
                }
            } else {
                printf("[AVERTISMENT] Conditie invalida ignorata: %s\n", argv[i]);
                all_match = 0;
                break;
            }
        }
        if (all_match) {
            printf("MATCH -> ID: %d | Cat: %s | Sev: %d | %s\n", r.id, r.category, r.severity, r.description);
        }
    }
    close(fd);
}

void update_threshold(const char *district, const char *value) {
    char path[1024];
    snprintf(path, sizeof(path), "%s/district.cfg", district);

    struct stat st;
    if (stat(path, &st) == 0) {
        if ((st.st_mode & 0777) != 0640) {
            printf("[EROARE] Permisiunile fisierului district.cfg au fost modificate! Refuz operatiunea.\n");
            return;
        }
    }

    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0640);
    if (fd != -1) {
        char buffer[256];
        snprintf(buffer, sizeof(buffer), "threshold=%s\n", value);
        write(fd, buffer, strlen(buffer));
        close(fd);
        printf("Threshold actualizat la %s.\n", value);
    }
}

int main(int argc, char *argv[]) {
    char *role = NULL, *user = "unknown", *command = NULL, *district = NULL;
    int district_idx = -1;

    // 1. Parsarea argumentelor din linia de comanda
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--role") == 0 && i + 1 < argc) {
            role = argv[++i];
        } else if (strcmp(argv[i], "--user") == 0 && i + 1 < argc) {
            user = argv[++i];
        } else if (command == NULL) {
            command = argv[i];
        } else if (district == NULL) {
            district = argv[i];
            district_idx = i;
        }
    }

    // 2. Validarea argumentelor de baza
    if (role == NULL || command == NULL || district == NULL) {
        printf("Utilizare: %s --role <manager|inspector> [--user <nume>] <comanda> <district> [argumente]\n", argv[0]);
        return 1;
    }

    if (strcmp(role, "manager") != 0 && strcmp(role, "inspector") != 0) {
        printf("Eroare: Rol invalid! (manager/inspector).\n");
        return 1;
    }

    int first_command_arg = district_idx + 1;

    // 3. Executarea comenzilor
    
    // Crearea/actualizarea automata a symlink-ului la fiecare rulare
   if (strcmp(command, "remove_district") != 0) {
        handle_symlink(district);
    }

    if (strcmp(command, "add") == 0) {
        add(district, role, user);
    } 
    else if (strcmp(command, "list") == 0) {
        list_reports(district, role);
    } 
    else if (strcmp(command, "view") == 0) {
        if (first_command_arg < argc) {
            int id_report;
            if (parse_int_arg(argv[first_command_arg], &id_report)) {
                view(district, id_report);
            } else {
                printf("ID raport invalid.\n");
            }
        } else {
            printf("Lipseste ID-ul raportului.\n");
        }
    } 
    else if (strcmp(command, "remove_district") == 0) {
        remove_district(district, role);
    } 
    else if (strcmp(command, "update_threshold") == 0) {
        if (strcmp(role, "manager") == 0) {
            if (first_command_arg < argc) {
                update_threshold(district, argv[first_command_arg]);
            } else {
                printf("Lipseste valoarea pragului.\n");
            }
        } else {
            printf("Acces refuzat: Doar managerul poate schimba pragul.\n");
        }
    } 
    else if (strcmp(command, "filter") == 0) {
        filter_reports(district, argc, argv, first_command_arg);
    } 
    else if (strcmp(command, "remove_report") == 0) {
        if (first_command_arg < argc) {
            int id_report;
            if (parse_int_arg(argv[first_command_arg], &id_report)) {
                remove_report(district, role, user, id_report);
            } else {
                printf("ID raport invalid.\n");
            }
        } else {
            printf("Lipseste ID-ul raportului de sters.\n");
        }
    } 
    else {
        printf("Comanda necunoscuta: %s\n", command);
        return 1;
    }

    return 0;
}